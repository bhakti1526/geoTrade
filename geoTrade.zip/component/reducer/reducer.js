export const Reducer = (state, action) => {
  switch (action.type) {
    default:
      return state;
  }
};
