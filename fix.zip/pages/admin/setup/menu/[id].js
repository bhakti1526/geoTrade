import React from "react";

const id = () => {
  return <div></div>;
};

export default id;
